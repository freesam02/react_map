import React from 'react';
import './App.scss';
import Main from './components/Main';


function App() {
  return (
    <div className="container">
      <Main />

    </div>
  );
}

export default App;
