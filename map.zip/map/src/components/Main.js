import React from 'react';
import {Container, Row, Col} from 'react-bootstrap';
import MyCalendar from './MyCalendar';
function Main() {
  return (
    <div>
<Container fluid="md">
  <Row>
    <Col>Couple History Map Header</Col>
  </Row>
  <Row>
    <Col>일정 추가 </Col>
  </Row>
  <Row>
    <Col>일정 조회  
      <MyCalendar />
    </Col>
  </Row>
</Container>
</div>
  );
}

export default Main;
